# standard library
import itertools
import json

from collections.abc import Callable

# third parties
from pydantic import BaseModel
from starlette.datastructures import Headers
from starlette.requests import Request
from starlette.responses import Response

flatten = itertools.chain.from_iterable


class BrowserCacheDirective(BaseModel):
    """
    Cache directive to the intention of
    :class:`BrowserCacheStore <w3nest.app.environment.browser_cache_store.BrowserCacheStore>`.
    """

    filepath: str
    """
    Path of the file on disk.
    """
    service: str
    """
    Name of the service that generated this directive.
    """


class KnownHeaders:
    """
    Gather headers and operations on headers.
    """

    #  About tracing & headers: https://www.w3.org/TR/trace-context/
    local_only: str = "local-only"
    """
    If this header is true, no operation involving the remote ecosystem is enabled.
    """
    origin: str = "origin"
    correlation_id: str = "x-correlation-id"
    """
    Correlation id (see [trace & context](https://www.w3.org/TR/trace-context/)).
    """
    trace_id: str = "x-trace-id"
    """
    Trace id (see [trace & context](https://www.w3.org/TR/trace-context/)).
    """

    trace_labels: str = "x-trace-labels"
    """
    Labels to associate with the trace, provided as a JSON array.
    """

    trace_attributes: str = "x-trace-attributes"
    """
    Attributes to associate with the trace, provided as a JSON dict.
    """

    server_port: str = "server_port"
    """
    Convey the port on which the local server is listenning on `localhost`.
    """

    backends_partition: str = "x-backends-partition"
    """
    Target partition regarding backends calls.
    """

    browser_cache_directive = "browser_cache_directive"
    """
    This header key is to be included to enable the
    :class:`BrowserCacheStore <w3nest.app.environment.browser_cache_store.BrowserCacheStore>` to cache a response,
    see the function
    :func:`w3nest_client.common.headers.KnownHeaders.set_browser_cache_directive`.
    """

    @staticmethod
    def get_correlation_id(request: Request) -> str | None:
        """

        Parameters:
            request: Incoming request.
        Return:
            Correlation id of the request, if provided.
        """
        return request.headers.get(KnownHeaders.correlation_id, None)

    @staticmethod
    def get_trace_id(request: Request) -> str | None:
        """

        Parameters:
            request: Incoming request.
        Return:
            Trace id of the request, if provided.
        """
        return request.headers.get(KnownHeaders.trace_id, None)

    @staticmethod
    def get_trace_labels(request: Request) -> list[str]:
        """

        Parameters:
            request: Incoming request.

        Return:
            Trace's labels from the request's headers, if provided.

        Raise:
            `ValueError` when decoding the label header failed.
        """
        raw = request.headers.get(KnownHeaders.trace_labels, "[]")
        labels = json.loads(raw)
        if not isinstance(labels, list):
            raise ValueError("Trace label's header should be provided as an array.")
        return [str(label) for label in labels]

    @staticmethod
    def get_trace_attributes(request: Request) -> dict[str, int | str | bool]:
        """

        Parameters:
            request: Incoming request.

        Return:
            Trace's attributes from the request's headers, if provided.

        Raise:
            `ValueError` when decoding the attribute header failed.
        """
        raw = request.headers.get(KnownHeaders.trace_attributes, "{}")

        attributes = json.loads(raw)
        if not isinstance(attributes, dict):
            raise ValueError(
                "Trace attribute's header should be provided as a dictionary."
            )
        return attributes

    @staticmethod
    def get_local_only(request: Request) -> str | None:
        """

        Parameters:
            request: Incoming request.
        Return:
            The value of the header 'local-only' if included in the request.
        """
        return request.headers.get(KnownHeaders.local_only, None)

    @staticmethod
    def get_backends_partition(request: Request, default_id: str) -> str:
        """

        Parameters:
            request: Incoming request.
            default_id: Default partition id to use if no partition id is provided.
        Return:
            Target partition ID, if available.
        """
        return request.headers.get(KnownHeaders.backends_partition, default_id)

    @staticmethod
    def get_browser_cache_info(
        response: Response,
    ) -> BrowserCacheDirective | None:
        """
        Retrieves an eventual directive regarding caching within
        :class:`BrowserCacheStore <w3nest.app.environment.browser_cache_store.BrowserCacheStore>`.

        Parameters:
            response: Response to retrieve the directive from, using the header
                :attr:`yw_browser_cache_directive <w3nest_client.common.headers.KnownHeaders.browser_cache_directive>`.

        Returns:
            The directive if found.
        """
        info = response.headers.get(KnownHeaders.browser_cache_directive, None)
        if info:
            return BrowserCacheDirective(**json.loads(info))

        return None

    @staticmethod
    def set_browser_cache_directive(
        response: Response, directive: BrowserCacheDirective
    ) -> None:
        """
        Set directive for
        :class:`BrowserCacheStore <w3nest.app.environment.browser_cache_store.BrowserCacheStore>` to cache a response.

        Parameters:
            response: The response to instrument for caching.
            directive: Required information about the resource to be cached.
        """
        response.headers.append(
            KnownHeaders.browser_cache_directive, json.dumps(directive.dict())
        )


def generate_headers_downstream(
    incoming_headers: Headers,
    from_req_fwd: Callable[[list[str]], list[str]] = lambda _keys: [],
):
    # the following headers are set when a request is sent anyway
    black_list = ["content-type", "content-length", "content-encoding"]
    headers_keys = [h.lower() for h in incoming_headers.keys()]
    to_propagate = [h.lower() for h in from_req_fwd(headers_keys)] + [
        "authorization",
        KnownHeaders.local_only,
        KnownHeaders.backends_partition,
    ]

    return {
        k: v
        for k, v in incoming_headers.items()
        if k.lower() in to_propagate and k.lower() not in black_list
    }
