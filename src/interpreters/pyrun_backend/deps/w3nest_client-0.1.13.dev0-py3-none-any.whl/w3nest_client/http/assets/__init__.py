"""
HTTP client & related for the :mod:`assets <w3nest.shared_api.assets>` service.
"""

# relative
from .assets import *
from .models import *
