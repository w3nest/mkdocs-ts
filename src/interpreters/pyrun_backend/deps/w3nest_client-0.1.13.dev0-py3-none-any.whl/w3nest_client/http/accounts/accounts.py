# standard library
from dataclasses import dataclass

# W3Nest Client
from w3nest_client.http.accounts.models import SessionResp

# W3Nest client
from w3nest_client.http.aiohttp_utils import AioHttpExecutor, typed_reader


@dataclass(frozen=True)
class AccountsClient:
    """
    HTTP client of the :mod:`accounts <w3nest.shared_api.accounts>` service.
    """

    url_base: str
    """
    Base URL used for the request.
    """

    request_executor: AioHttpExecutor
    """
    Request executor.
    """

    async def get_session_details(self, **kwargs) -> SessionResp:
        """
        See description in
        :func:`w3nest.shared_api.accounts.root_paths.get_session_details`
        """
        return await self.request_executor.get(
            url=f"{self.url_base}/session",
            reader=typed_reader(SessionResp),
            **kwargs,
        )
