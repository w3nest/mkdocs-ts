# third parties
from pydantic import BaseModel


class Group(BaseModel):
    """
    Specification of a group.
    """

    id: str
    """
    Group ID.
    """
    path: str
    """
    Group path.
    """


class UserInfo(BaseModel):
    name: str
    """
    Name of the user.
    """
    temp: bool | None
    groups: Group


class SessionResp(BaseModel):
    """
    Response model for a session.
    """

    userInfo: UserInfo
    logoutUrl: str
    accountManagerUrl: str
    remembered: bool
