# standard library
from dataclasses import dataclass

# W3Nest Client
from w3nest_client.common.json_utils import JSON
from w3nest_client.http.aiohttp_utils import (
    AioHttpExecutor,
    EmptyResponse,
    json_reader,
    typed_reader,
)


@dataclass(frozen=True)
class WebpmSessionsStorageClient:
    """
    HTTP client of the :mod:`w3nest.shared_api.webpm_sessions_storage` service.
    """

    url_base: str
    """
    Base URL used for the request.
    """
    request_executor: AioHttpExecutor
    """
    Request executor.
    """

    def base_path(self, package: str, key: str):
        return f"{self.url_base}/applications/{package}/{key}"

    async def get(
        self, package: str, key: str, headers: dict[str, str], **kwargs
    ) -> JSON:
        """
        See description in
        :func:`w3nest.shared_api.webpm_sessions_storage.root_paths.get_data_no_namespace`
        """
        return await self.request_executor.get(
            url=self.base_path(package, key),
            reader=json_reader,
            headers=headers,
            **kwargs,
        )

    async def post(
        self, package: str, key: str, body: JSON, headers: dict[str, str], **kwargs
    ) -> EmptyResponse:
        """
        See description in
        :func:`w3nest.shared_api.webpm_sessions_storage.root_paths.post_data_no_namespace`
        """
        return await self.request_executor.post(
            url=self.base_path(package, key),
            reader=typed_reader(EmptyResponse),
            json=body,
            headers=headers,
            **kwargs,
        )
