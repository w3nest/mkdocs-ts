# typing
from typing import Generic, TypeVar

# third parties
from pydantic import BaseModel

# W3Nest Client
from w3nest_client.http.assets import AssetResponse

RawT = TypeVar("RawT", bound=BaseModel)
"""
Generic specification of the type of a raw response when creating an asset.
"""


class NewAssetResponse(AssetResponse, Generic[RawT]):
    """
    Asset description when creating an asset using
    :func:`create_asset <w3nest.shared_api.assets_gtw.routers.assets.create_asset>`
    """

    itemId: str
    """
    Item ID
    """
    rawResponse: RawT | None
    """
    Response from the underlying service manager of the 'raw' part of the asset; if any.
    """
