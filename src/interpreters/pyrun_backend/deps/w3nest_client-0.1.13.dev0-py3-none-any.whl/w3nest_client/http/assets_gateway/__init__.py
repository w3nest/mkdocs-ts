"""
This module gathers HTTP client & related for the :mod:`assets-gateway <w3nest.shared_api.assets_gtw>` service.
"""

# relative
from .assets_gateway import *
from .models import *
